import matplotlib.pyplot as plt


def draw_histogram():
    languages = ["Python", "C++", "C", "Java", "C#", "JavaScript", "Go", "Visual Basic", "Delphi", "SQL"]
    ratings = [25.98, 8.80, 8.65, 8.35, 6.38, 3.22, 2.04, 1.95, 1.75, 1.72]
    plt.figure(figsize=(10, 6))
    plt.bar(languages, ratings, color="steelblue")
    plt.title("Популярность языков программирования (TIOBE)")
    plt.xlabel("Язык программирования")
    plt.ylabel("Рейтинг, %")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    draw_histogram()
