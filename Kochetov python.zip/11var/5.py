def count_russian(path):
    alphabet = [chr(code) for code in range(ord("А"), ord("я") + 1)] + [chr(ord("Ё")), chr(ord("ё"))]
    result = {}
    with open(path, encoding="utf-8") as file:
        for line in file:
            line = line.rstrip("\n")
            result[sum(1 for char in line if char in alphabet)] = line
    return result


if __name__ == "__main__":
    print(count_russian("text.txt"))
