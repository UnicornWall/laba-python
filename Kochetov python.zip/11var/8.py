import os
from PIL import Image


class GifProcessor:
    def split_gif(self, path):
        directory = os.path.dirname(os.path.abspath(path))
        name = os.path.splitext(os.path.basename(path))[0]
        with Image.open(path) as gif:
            for i in range(gif.n_frames):
                gif.seek(i)
                gif.convert("RGBA").save(os.path.join(directory, f"{name}_{i}.png"))

    def create_gif(self, directory):
        files = sorted(name for name in os.listdir(directory) if name.lower().endswith((".png", ".jpg", ".jpeg", ".bmp")))
        frames = [Image.open(os.path.join(directory, name)) for name in files]
        frames[0].save(os.path.join(directory, "result.gif"), save_all=True, append_images=frames[1:], duration=200, loop=0)


if __name__ == "__main__":
    processor = GifProcessor()
    processor.split_gif("gif/animation.gif")
    processor.create_gif("gif")
