import time
from django.contrib.auth.models import User
from django.core.mail import send_mass_mail
from django.core.management.base import BaseCommand
from quotes.models import Quote


class Command(BaseCommand):
    help = 'Ежедневная рассылка случайной вдохновляющей цитаты зарегистрированным пользователям'

    def handle(self, *args, **options):
        while True:
            quote = Quote.objects.order_by('?').first()
            emails = list(User.objects.exclude(email='').values_list('email', flat=True))
            if quote and emails:
                send_mass_mail([('Цитата дня', f'{quote.text}\n\n{quote.author}', None, [email]) for email in emails])
                self.stdout.write(f'Цитата отправлена пользователям: {len(emails)}')
            time.sleep(24 * 60 * 60)
