from django.db import models


class Quote(models.Model):
    text = models.TextField('Текст')
    author = models.CharField('Автор', max_length=200)

    class Meta:
        verbose_name = 'Цитата'
        verbose_name_plural = 'Цитаты'

    def __str__(self):
        return f'{self.text} — {self.author}'
