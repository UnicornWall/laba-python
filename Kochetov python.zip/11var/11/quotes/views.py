from django.contrib.auth import login
from django.shortcuts import render, redirect
from .forms import RegisterForm
from .models import Quote


def index(request):
    quote = Quote.objects.order_by('?').first()
    return render(request, 'quotes/index.html', {'quote': quote})


def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('index')
    else:
        form = RegisterForm()
    return render(request, 'quotes/register.html', {'form': form})
