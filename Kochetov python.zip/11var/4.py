import os


def get_files(path):
    return [name for name in os.listdir(path) if os.path.isfile(os.path.join(path, name))]


if __name__ == "__main__":
    print(get_files("gif"))
