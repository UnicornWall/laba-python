import sqlite3
import tkinter as tk
from tkinter import ttk, filedialog, messagebox


class DatabaseApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Работа с базой данных")
        self.root.geometry("700x500")
        self.connection = None

        frame_connect = tk.Frame(self.root)
        frame_connect.pack(fill=tk.X, padx=5, pady=5)
        tk.Label(frame_connect, text="Файл БД:").pack(side=tk.LEFT)
        self.path_entry = tk.Entry(frame_connect)
        self.path_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        tk.Button(frame_connect, text="Обзор", command=self.browse).pack(side=tk.LEFT)
        tk.Button(frame_connect, text="Подключиться", command=self.connect).pack(side=tk.LEFT, padx=5)
        self.status_label = tk.Label(self.root, text="Не подключено", fg="red")
        self.status_label.pack(anchor=tk.W, padx=5)

        tk.Label(self.root, text="Запрос:").pack(anchor=tk.W, padx=5)
        self.query_text = tk.Text(self.root, height=5)
        self.query_text.pack(fill=tk.X, padx=5)
        tk.Button(self.root, text="Выполнить", command=self.execute).pack(anchor=tk.E, padx=5, pady=5)

        self.result_tree = ttk.Treeview(self.root, show="headings")
        self.result_tree.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    def browse(self):
        path = filedialog.askopenfilename(filetypes=[("SQLite", "*.db *.sqlite *.sqlite3"), ("Все файлы", "*.*")])
        if path:
            self.path_entry.delete(0, tk.END)
            self.path_entry.insert(0, path)

    def connect(self):
        try:
            if self.connection:
                self.connection.close()
            self.connection = sqlite3.connect(self.path_entry.get())
            self.status_label.config(text=f"Подключено: {self.path_entry.get()}", fg="green")
        except sqlite3.Error as error:
            messagebox.showerror("Ошибка", str(error))

    def execute(self):
        if not self.connection:
            messagebox.showwarning("Ошибка", "Нет соединения с базой данных")
            return
        try:
            cursor = self.connection.cursor()
            cursor.execute(self.query_text.get("1.0", tk.END))
            self.connection.commit()
            self.result_tree.delete(*self.result_tree.get_children())
            if cursor.description:
                columns = [column[0] for column in cursor.description]
                self.result_tree["columns"] = columns
                for column in columns:
                    self.result_tree.heading(column, text=column)
                for row in cursor.fetchall():
                    self.result_tree.insert("", tk.END, values=row)
            else:
                self.result_tree["columns"] = []
                messagebox.showinfo("Результат", f"Изменено строк: {cursor.rowcount}")
        except sqlite3.Error as error:
            messagebox.showerror("Ошибка", str(error))


if __name__ == "__main__":
    root = tk.Tk()
    DatabaseApp(root)
    root.mainloop()
