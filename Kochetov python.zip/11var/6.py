import sqlite3


def find_id(table, field, value):
    connection = sqlite3.connect("library.db")
    cursor = connection.cursor()
    cursor.execute(f"SELECT id FROM {table} WHERE {field} = :value", {"value": value})
    row = cursor.fetchone()
    connection.close()
    return row[0] if row else None


if __name__ == "__main__":
    print(find_id("Author", "name", "Лев Толстой"))
    print(find_id("Book", "title", "Мастер и Маргарита"))
    print(find_id("Author", "name", "Неизвестный автор"))
