def items_range(items, a, b):
    for i in range(a, min(b, len(items) - 1) + 1):
        yield items[i]


def print_range(items, a, b):
    for item in items_range(items, a, b):
        print(item)


if __name__ == "__main__":
    print_range([10, 20, 30, 40, 50, 60], 2, 4)
    print("---")
    print_range([10, 20, 30, 40, 50, 60], 3, 15)
    print("---")
    print_range([10, 20, 30, 40, 50, 60], 10, 15)
