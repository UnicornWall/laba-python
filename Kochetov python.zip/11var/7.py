class Parent:
    def display(self):
        print("Метод display родительского класса")


class Child(Parent):
    def display(self):
        print("Метод display дочернего класса")


if __name__ == "__main__":
    Parent().display()
    Child().display()
