def generate_list(n):
    return list(range(n + 1))


if __name__ == "__main__":
    print(generate_list(10))
