def has_123(numbers):
    for i in range(len(numbers) - 2):
        if sorted(numbers[i:i + 3]) == [1, 2, 3]:
            return True
    return False


if __name__ == "__main__":
    print(has_123([5, 3, 1, 2, 7]))
    print(has_123([1, 2, 4, 3, 1]))
